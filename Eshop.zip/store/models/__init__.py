from .product import Product
from .category import Category
from  .customer import  Customer
from  .orders import Order
from .views import index

urlpatterns=[
    path('',index),
    path('signup')
]